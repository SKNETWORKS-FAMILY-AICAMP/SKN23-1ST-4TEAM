#유저

get_owner_count_by_age()
get_owner_count_by_region()
get_owner_avg_age()