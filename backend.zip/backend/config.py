


"""

==========================================
1. ⚙ Global Config (기본 설정값)
==========================================

## 📌 Database Settings
- HOST: skn23-1st-4team.cr6u26mg6lbq.eu-north-1.rds.amazonaws.com
- USER: <입력>
- PASSWORD: <입력>
- DATABASE: <입력>
- PORT: 3306

# SSH SQL 터미널 설정
Connection Type: MySQL
Host: skn23-1st-4team.cr6u26mg6lbq.eu-north-1.rds.amazonaws.com
Port: 3306

Use SSH Tunnel: ✔  
- SSH Host: ec2-13-61-174-247.eu-north-1.compute.amazonaws.com
- SSH User: ec2-user
- Private Key: <.pem 파일 경로>
- SSH Port: 22
"""